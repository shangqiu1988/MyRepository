//
//  NewViewController.swift
//  BSBDJ
//
//  Created by apple on 2017/11/6.
//  Copyright © 2017年 incich. All rights reserved.
//

import UIKit

class NewViewController: EssenceViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        navigationItem.titleView = nil;
       navigationItem.title = "新帖"
    }
}
