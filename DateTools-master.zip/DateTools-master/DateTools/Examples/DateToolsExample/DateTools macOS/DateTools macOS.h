//
//  DateTools macOS.h
//  DateTools macOS
//
//  Created by Tom Baranes on 22/09/2016.
//
//

#import <Cocoa/Cocoa.h>

//! Project version number for DateTools macOS.
FOUNDATION_EXPORT double DateTools_macOSVersionNumber;

//! Project version string for DateTools macOS.
FOUNDATION_EXPORT const unsigned char DateTools_macOSVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <DateTools_macOS/PublicHeader.h>


