mkdir docs
cd Tests/DateToolsTests
jazzy -a Matthew\ York,\ Grayson\ Webster -u https://github.com/MatthewYork -g https://github.com/MatthewYork/DateTools -o ../../docs