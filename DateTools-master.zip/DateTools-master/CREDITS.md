Credits
=======

Portions from NSDate+TimeAgo Originally based on code Christopher Pickslay posted to Forrst. Used with permission. http://twitter.com/cpickslay

Ramon Torres began support for internationalization/localization. Added es strings. http://rtorres.me/

Dennis Zhuang added zh_Hans Chinese Simplified strings. http://fnil.net/

Mozart Petter added pt_BR Brazilian Portuguese strings. http://www.mozartpetter.com/

Stéphane Gerardot added fr French strings.

Marco Sanson added it Italian strings. http://marcosanson.tumblr.com/

Almas Adilbek added ru Russian strings. Extended logic to support Russian idioms. http://mixdesign.kz/

Mallox51 added de German strings. https://github.com/Mallox51

Tieme van Veen added nl Dutch strings. http://www.tiemevanveen.nl

Árpád Goretity added hu Hungarian strings. http://apaczai.elte.hu/~13akga/

Anajavi added fi Finnish strings. https://github.com/anajavi

Tonydyb added ja Japanese strings.

Vinhnx added vi Vietnamese strings. http://vinhnx.github.io/

Ronail added zh_Hant Traditional Chinese strings. https://github.com/ronail

SorinAntohi added ro Romanian strings. https://github.com/SorinAntohi

spookd added da Danish strings. https://github.com/spookd

Barrett Jacobsen added cs Czech strings. https://github.com/barrettj

Dmitry Shmidt added nb Norwegian strings. https://github.com/shmidt

Martins Rudens added lv Latvian strings. https://github.com/rudensm

Osman Saral added tr Turkish strings. https://github.com/osrl

analogstyle added ko Korean strings. http://almacreative.net/

Flavio Caetano fixed pt Portuguese strings. http://flaviocaetano.com

kolarski added bg Bulgarian strings. http://github.com/kolarski

Vladimir Kofman added he Hebrew strings. https://github.com/vladimirkofman

Viraf Sarkari added ar Arabic, gre Greek, pl Polish, sv Swedish, and th Thai strings. https://github.com/viraf

Vasyl Skrypii added uk Ukranian strings. https://github.com/medlay

Maggi Trymbill added is Icelandic strings. https://github.com/grundvollur

Ikhsan Assaat added id Indonesian strings. http://ikhsan.me

Marc added ca Catalan strings. http://marcboquet.com/

Steffan Harries added cy Welsh strings. https://github.com/Bendihossan

mjanda added es and cs short format strings https://github.com/mjanda

Niklas Fahl added the de short format strings https://github.com/fahlout

Vlad Cacuic added the ro short format strings https://github.com/vrcaciuc

frin added sl Slovenian strings. http://github.com/frin

Nikhil Nigade added hi (Hindi) and gu (Gujarati) strings. https://github.com/dezinezync

Faiz Mokhtar added ms Malay strings. https://github.com/faizmokhtar

Jakub Olejník (https://github.com/olejnjak) and Jakub Truhlář (https://github.com/kubatru) added sk (Slovak) strings
