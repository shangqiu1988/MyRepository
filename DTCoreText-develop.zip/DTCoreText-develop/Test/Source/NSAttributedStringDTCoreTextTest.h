//
//  NSAttributedStringDTCoreTextTest.h
//  DTCoreText
//
//  Created by Oliver Drobnik on 30.09.13.
//  Copyright (c) 2013 Drobnik.com. All rights reserved.
//

#import "DTCoreTextTestCase.h"

@interface NSAttributedStringDTCoreTextTest : DTCoreTextTestCase

@end
