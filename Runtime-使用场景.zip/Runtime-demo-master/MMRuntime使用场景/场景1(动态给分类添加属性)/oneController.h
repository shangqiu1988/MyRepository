//
//  oneController.h
//  MMRuntime
//
//  Created by mengxuanlong on 17/5/9.
//  Copyright © 2017年 mengxuanlong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "MMBaseController.h"

@interface oneController : MMBaseController

@end
