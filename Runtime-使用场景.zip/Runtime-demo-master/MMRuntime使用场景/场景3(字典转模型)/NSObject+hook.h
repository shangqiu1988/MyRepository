//
//  NSObject+hook.h
//  MMRuntime
//
//  Created by mengxuanlong on 17/5/9.
//  Copyright © 2017年 mengxuanlong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSObject (hook)
+ (instancetype)modelWithDict:(NSDictionary *)dict;

@end
