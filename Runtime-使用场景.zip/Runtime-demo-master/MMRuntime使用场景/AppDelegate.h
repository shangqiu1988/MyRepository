//
//  AppDelegate.h
//  MMRuntime使用场景
//
//  Created by mengxuanlong on 17/6/7.
//  Copyright © 2017年 mengxuanlong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;


@end

