//
//  main.swift
//  AVLTree
//
//  Created by ZeluLi on 2016/10/29.
//  Copyright © 2016年 zeluli. All rights reserved.
//

import Foundation

let searchTable: Array<Int> = [3, 2, 1, 4, 5, 6, 7, 10, 9, 8]
let avlTree = AVLTree(items: searchTable)

avlTree.deleteNote(key: 1)
avlTree.inOrderTraverse()
