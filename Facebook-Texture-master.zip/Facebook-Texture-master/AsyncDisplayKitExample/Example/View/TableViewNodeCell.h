//
//  TableViewNodeCell.h
//  LuisXKit
//
//  Created by LuisX on 2016/12/14.
//  Copyright © 2016年 LuisX. All rights reserved.
//

#import <AsyncDisplayKit/AsyncDisplayKit.h>

@interface TableViewNodeCell : ASCellNode
- (instancetype)initWithHaiTao:(BOOL)haiTao;
@end
