//
//  AppDelegate.h
//  CTUnlimitedView
//
//  Created by 酌晨茗 on 16/2/15.
//  Copyright © 2016年 酌晨茗. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end