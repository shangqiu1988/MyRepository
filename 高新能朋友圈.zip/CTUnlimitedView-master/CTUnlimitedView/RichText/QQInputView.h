//
//  QQInputView.h
//  CTUnlimitedView
//
//  Created by boleketang on 16/9/22.
//  Copyright © 2016年 zhuochenming. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QQInputView : UIView

@property (nonatomic, strong) UITextField *messageTextField;

@property (nonatomic, strong) UIButton *sendButton;

@end
